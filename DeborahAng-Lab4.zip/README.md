# DeborahAng-Websys_Lab4
WebSys Lab04

Part 1
I made a simple json file where I have a songbook that has a list of each song with its relevant information. Each attribute name has semantic meaning and should be readable.
Part 2
I actually changed the html of my lab2-part3 for this lab just because I felt like I could do a better job than what I did for the previous lab. The CSS was practically the same, all I did was use unordered lists to make the table. I think my newer html actually has more semantic meaning to the html than my lab2-part3 did. After clicking the CD image, I use a GET request with AJAX to get the JSON file and then I append each JSON attribute as a list element in my lab4 html. I also included an images folder for all the album cover images.

Here's the github link:
https://github.com/dang32/DeborahAng-Websys_Lab4
